﻿      param
        (
            [Parameter(Mandatory=$True)]
            $RegistrationUrl,

            [Parameter(Mandatory=$True)]
            [PSCredential]$RegistrationKey,

            #[Parameter(Mandatory=$True)]
            #[string]$NodeConfigurationName,

            [Parameter(Mandatory=$True)]
            [string]$role
        )
[Environment]::SetEnvironmentVariable("nodeRole", "$role", "Machine")
[DscLocalConfigurationManager()]
Configuration RegistrationMetaConfigV2
{
        Settings
        {
            RefreshFrequencyMins = '30'
            RefreshMode = "PULL"
            ConfigurationMode = 'ApplyandAutoCorrect'
            AllowModuleOverwrite  = $true
            RebootNodeIfNeeded = $true
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationModeFrequencyMins = '15'
        }


        ConfigurationRepositoryWeb AzureAutomationDSC
        {
            ServerUrl = $RegistrationUrl 
            RegistrationKey = $RegistrationKey.GetNetworkCredential().Password
            ConfigurationNames = $ConfigurationNames
        }     
        
        ResourceRepositoryWeb AzureAutomationDSC
        {
            ServerUrl = $RegistrationUrl
            RegistrationKey = $RegistrationKey.GetNetworkCredential().Password
        }
  
        ReportServerWeb AzureAutomationDSC
        {
            ServerUrl = $RegistrationUrl
            RegistrationKey = $RegistrationKey.GetNetworkCredential().Password 
        }

}